#!/bin/bash
/usr/lib/gnome-settings-daemon/gsd-xsettings
